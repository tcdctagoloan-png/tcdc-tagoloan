// lib/book_page.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

const int MAX_BED_CAPACITY = 17; // Total per bed per slot (adjust per facility)

class BookPage extends StatefulWidget {
  final String userId;
  const BookPage({super.key, required this.userId});

  @override
  State<BookPage> createState() => _BookPageState();
}

class _BookPageState extends State<BookPage> {
  DateTime selectedDate = DateTime.now().add(const Duration(days: 1));

  bool _isWideScreen(BuildContext context) =>
      MediaQuery.of(context).size.width >= 900;

  Future<void> _selectDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime.now().add(const Duration(days: 1)),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );

    if (picked != null) {
      // 🧩 Prevent Sunday booking
      if (picked.weekday == DateTime.sunday) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Booking not allowed on Sundays')),
        );
        return;
      }
      setState(() => selectedDate = picked);
    }
  }

  String formatTimeRange(Timestamp start, Timestamp end) {
    final startTime = DateFormat.jm().format(start.toDate());
    final endTime = DateFormat.jm().format(end.toDate());
    return "$startTime - $endTime";
  }

  Future<Map<String, int>> _fetchBedAssignmentCounts(
      DateTime date, String slot) async {
    final DateTime onlyDate = DateTime(date.year, date.month, date.day);
    final Timestamp tsStart = Timestamp.fromDate(onlyDate);
    final Timestamp tsEnd =
    Timestamp.fromDate(onlyDate.add(const Duration(days: 1)));

    final snap = await FirebaseFirestore.instance
        .collection('appointments')
        .where('date', isGreaterThanOrEqualTo: tsStart)
        .where('date', isLessThan: tsEnd)
        .where('slot', isEqualTo: slot)
        .where('status', whereIn: ['pending', 'approved', 'rescheduled'])
        .get();

    final Map<String, int> bedCounts = {};
    for (var doc in snap.docs) {
      final bedId = (doc.data() as Map<String, dynamic>)['bedId']?.toString();
      if (bedId != null) bedCounts[bedId] = (bedCounts[bedId] ?? 0) + 1;
    }
    return bedCounts;
  }

  Future<void> _bookSlot(String slotTimeRange, String? bedId) async {
    try {
      // 🧩 Prevent multiple active bookings
      final existing = await FirebaseFirestore.instance
          .collection('appointments')
          .where('patientId', isEqualTo: widget.userId)
          .where('status', whereIn: ['pending', 'approved', 'rescheduled'])
          .get();

      if (existing.docs.isNotEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('You already have an active booking')),
        );
        return;
      }

      // 🧩 Check allowed patient schedule (MWF or TThS)
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.userId)
          .get();

      final userData = userDoc.data();
      final allowedDays =
          (userData?['scheduleDays'] as List?)?.cast<String>() ?? [];

      final weekdayName = DateFormat('EEE').format(selectedDate); // e.g. Mon

      if (allowedDays.isNotEmpty && !allowedDays.contains(weekdayName)) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'You can only book on your assigned days: ${allowedDays.join(", ")}',
            ),
          ),
        );
        return;
      }

      // 🧩 Proceed to booking
      final appointmentRef = await FirebaseFirestore.instance
          .collection('appointments')
          .add({
        'patientId': widget.userId,
        'date': Timestamp.fromDate(
            DateTime(selectedDate.year, selectedDate.month, selectedDate.day)),
        'slot': slotTimeRange,
        'status': 'pending',
        'bedId': bedId,
        'createdAt': FieldValue.serverTimestamp(),
      });

      // 🧩 Notify nurses
      await FirebaseFirestore.instance.collection('notifications').add({
        'nurseId': 'all',
        'title': 'New Appointment Request',
        'message':
        'Patient booked $slotTimeRange on ${DateFormat('y-MM-dd').format(selectedDate)}',
        'appointmentId': appointmentRef.id,
        'read': false,
        'createdAt': FieldValue.serverTimestamp(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Successfully booked $slotTimeRange'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Error: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final isWideScreen = _isWideScreen(context);

    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Book Your Appointment",
                    style: TextStyle(
                      fontSize: isWideScreen ? 28 : 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Selected Date: ${DateFormat('y-MM-dd').format(selectedDate)}",
                        style: const TextStyle(fontSize: 16),
                      ),
                      ElevatedButton.icon(
                        onPressed: _selectDate,
                        icon: const Icon(Icons.calendar_today, size: 18),
                        label: const Text("Change"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green.shade700,
                          foregroundColor: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Slot List
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('session')
                    .orderBy('startTime')
                    .snapshots(),
                builder: (context, sessionSnap) {
                  if (sessionSnap.connectionState == ConnectionState.waiting) {
                    return const Center(
                        child:
                        CircularProgressIndicator(color: Colors.green));
                  }

                  if (!sessionSnap.hasData || sessionSnap.data!.docs.isEmpty) {
                    return const Center(
                        child: Text("No available slots from admin"));
                  }

                  final activeSlots = sessionSnap.data!.docs.where((doc) {
                    final data = doc.data() as Map<String, dynamic>;
                    return data['isActive'] == true;
                  }).toList();

                  if (activeSlots.isEmpty) {
                    return const Center(
                        child: Text("All slots are currently unavailable"));
                  }

                  return ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: activeSlots.length,
                    itemBuilder: (context, index) {
                      final slotDoc = activeSlots[index];
                      final slotData = slotDoc.data() as Map<String, dynamic>;
                      final start = slotData['startTime'] as Timestamp;
                      final end = slotData['endTime'] as Timestamp;
                      final timeRange = formatTimeRange(start, end);

                      return FutureBuilder<Map<String, int>>(
                        future:
                        _fetchBedAssignmentCounts(selectedDate, timeRange),
                        builder: (context, bedSnap) {
                          if (!bedSnap.hasData) {
                            return const Padding(
                              padding: EdgeInsets.all(8.0),
                              child: LinearProgressIndicator(),
                            );
                          }

                          final bedCounts = bedSnap.data!;
                          return FutureBuilder<QuerySnapshot>(
                            future: FirebaseFirestore.instance
                                .collection('beds')
                                .where('isWorking', isEqualTo: true)
                                .orderBy('name')
                                .get(),
                            builder: (context, bedsSnap) {
                              if (!bedsSnap.hasData) {
                                return const Center(
                                    child: CircularProgressIndicator());
                              }
                              if (bedsSnap.data!.docs.isEmpty) {
                                return const Center(
                                    child: Text("No working beds registered"));
                              }

                              // Find first available bed
                              String? availableBedId;
                              for (var bedDoc in bedsSnap.data!.docs) {
                                final bedId = bedDoc.id;
                                final assignedCount =
                                    bedCounts[bedId] ?? 0;
                                if (assignedCount < MAX_BED_CAPACITY) {
                                  availableBedId = bedId;
                                  break;
                                }
                              }

                              final isFull = availableBedId == null;

                              return Card(
                                margin:
                                const EdgeInsets.symmetric(vertical: 8),
                                color: isFull
                                    ? Colors.grey.shade300
                                    : Colors.white,
                                child: ListTile(
                                  leading: const Icon(Icons.access_time,
                                      color: Colors.green),
                                  title: Text(timeRange,
                                      style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16)),
                                  subtitle: Text(
                                    isFull ? "FULL" : "AVAILABLE",
                                    style: TextStyle(
                                      color: isFull
                                          ? Colors.red
                                          : Colors.green.shade700,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  trailing: isFull
                                      ? const Icon(Icons.lock,
                                      color: Colors.red)
                                      : ElevatedButton(
                                    onPressed: () => _bookSlot(
                                        timeRange, availableBedId),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor:
                                      Colors.green.shade700,
                                      foregroundColor: Colors.white,
                                      shape: RoundedRectangleBorder(
                                        borderRadius:
                                        BorderRadius.circular(8),
                                      ),
                                    ),
                                    child: const Text("Book"),
                                  ),
                                ),
                              );
                            },
                          );
                        },
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
