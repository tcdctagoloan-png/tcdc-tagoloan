// patient_dashboard.dart
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';

import 'appointment_page.dart';
import 'book_page.dart' as booking;
import 'notification_page.dart';
import 'profile_page.dart';
import 'home_page.dart';
import '../screens/login_page.dart';
import 'package:dialysis_app/reports/report_page.dart';

class PatientDashboard extends StatefulWidget {
  final String userId;
  const PatientDashboard({super.key, required this.userId});

  @override
  _PatientDashboardState createState() => _PatientDashboardState();
}

class _PatientDashboardState extends State<PatientDashboard> {
  int _index = 0;
  String _username = '';
  String _userEmail = '';
  bool _loadingName = true;
  late final List<Widget> _pages;
  late final String _patientId;
  int _unreadNotifications = 0;
  String? _profileImageBase64;

  final List<String> _titles = [
    "Home",
    "Appointments",
    "Book",
    "Profile",
    "Notifications",
    "History"
  ];

  @override
  void initState() {
    super.initState();
    _patientId = widget.userId;
    _userEmail = FirebaseAuth.instance.currentUser?.email ?? 'N/A';

    // placeholders — will be replaced after loading username
    _pages = [
      const Center(child: CircularProgressIndicator()),
      PatientAppointmentsPage(userId: _patientId),
      const Center(child: CircularProgressIndicator()),
      ProfilePage(userId: _patientId),
      PatientNotificationPage(userId: _patientId),
      ReportsPage(role: "patient", userId: _patientId),
    ];

    _loadUsername();
    _listenUnreadNotifications();
  }

  Future<void> _loadUsername() async {
    bool isVerified = false;
    String name = '';
    String? base64Image;

    try {
      final doc =
      await FirebaseFirestore.instance.collection('users').doc(_patientId).get();

      if (doc.exists && doc.data() != null) {
        final data = doc.data()!;
        name = (data['username'] ?? data['fullName'] ?? '').toString();
        isVerified = data['verified'] == true;
        base64Image = (data['profileImageBase64'] as String?) ?? data['profileImage'];
      }
    } catch (_) {
      name = '';
    } finally {
      if (!mounted) return;
      setState(() {
        _username = name;
        _profileImageBase64 = base64Image;
        _loadingName = false;

        // Wrap HomePage into HomeWrapper that contains the "How to Book" guide.
        _pages[0] = HomeWrapper(
          userId: _patientId,
          fullName: _username,
          child: HomePage(
            userId: _patientId,
            fullName: _username,
            onNavigate: _onTap,
          ),
        );

        _pages[2] = isVerified
            ? SafeArea(child: booking.BookPage(userId: _patientId))
            : const Center(
          child: Padding(
            padding: EdgeInsets.all(20),
            child: Text(
              "Booking is disabled until your account is verified.\n\n"
                  "Please pass all requirements to the admin.",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, color: Colors.grey),
            ),
          ),
        );
      });
    }
  }

  void _listenUnreadNotifications() {
    FirebaseFirestore.instance
        .collection('notifications')
        .where('patientId', isEqualTo: _patientId)
        .where('read', isEqualTo: false)
        .snapshots()
        .listen((snapshot) {
      if (mounted) {
        setState(() {
          _unreadNotifications = snapshot.docs.length;
        });
      }
    });
  }

  Future<void> _logout() async {
    await FirebaseAuth.instance.signOut();
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const LoginPage()),
    );
  }

  void _onTap(int idx) => setState(() => _index = idx);

  @override
  Widget build(BuildContext context) {
    final isWideScreen = MediaQuery.of(context).size.width >= 900;

    // Mobile layout
    if (!isWideScreen) {
      return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: Text(_titles[_index]),
          backgroundColor: Colors.green,
          foregroundColor: Colors.white,
          elevation: 4,
          actions: [
            IconButton(
              icon: const Icon(Icons.logout),
              tooltip: 'Logout',
              onPressed: _logout,
            ),
          ],
        ),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          color: Colors.white,
          child: _pages[_index],
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _index,
          onTap: _onTap,
          type: BottomNavigationBarType.fixed,
          selectedItemColor: Colors.green,
          unselectedItemColor: Colors.grey,
          items: [
            const BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
            const BottomNavigationBarItem(
                icon: Icon(Icons.calendar_today), label: "Appointments"),
            const BottomNavigationBarItem(
                icon: Icon(Icons.add_circle_outline), label: "Book"),
            const BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
            BottomNavigationBarItem(
              icon: Stack(
                clipBehavior: Clip.none,
                children: [
                  const Icon(Icons.notifications),
                  if (_unreadNotifications > 0)
                    Positioned(
                      right: -6,
                      top: -3,
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                        ),
                        constraints:
                        const BoxConstraints(minWidth: 20, minHeight: 20),
                        child: Center(
                          child: AnimatedSwitcher(
                            duration: const Duration(milliseconds: 300),
                            transitionBuilder:
                                (child, animation) => ScaleTransition(
                              scale: animation,
                              child: child,
                            ),
                            child: Text(
                              '$_unreadNotifications',
                              key: ValueKey<int>(_unreadNotifications),
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
              label: "Notifications",
            ),
            const BottomNavigationBarItem(
                icon: Icon(Icons.bar_chart), label: "History"),
          ],
        ),
      );
    }

    // Web layout
    return Scaffold(
      backgroundColor: Colors.white,
      body: Row(
        children: [
          // Sidebar
          Container(
            width: 240,
            color: Colors.white,
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    children: [
                      Image.asset(
                        kIsWeb ? 'logo/TCDC-LOGO.png' : 'assets/logo/TCDC-LOGO.png',
                        height: 100,
                        errorBuilder: (context, error, stackTrace) =>
                        const Icon(Icons.medical_services, size: 50, color: Colors.green),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        "TOTAL CARE DIALYSIS CENTER",
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.green),
                      ),
                      const Text(
                        "TAGOLOAN BRANCH",
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 10, fontWeight: FontWeight.w500, color: Colors.black54),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),
                  child: _PatientInfoCard(
                    username: _username,
                    email: _userEmail,
                    isLoading: _loadingName,
                    profileImageBase64: _profileImageBase64,
                  ),
                ),
                const Divider(),
                _WebNavItem(icon: Icons.home_filled, label: "Home", index: 0, currentIndex: _index, onTap: _onTap),
                _WebNavItem(icon: Icons.calendar_today_outlined, label: "Appointments", index: 1, currentIndex: _index, onTap: _onTap),
                _WebNavItem(icon: Icons.add_box_outlined, label: "Book", index: 2, currentIndex: _index, onTap: _onTap),
                _WebNavItem(icon: Icons.person_outline, label: "Profile", index: 3, currentIndex: _index, onTap: _onTap),
                _WebNavItem(icon: Icons.notifications_none, label: "Notifications", index: 4, currentIndex: _index, onTap: _onTap, badgeCount: _unreadNotifications),
                _WebNavItem(icon: Icons.bar_chart_outlined, label: "History", index: 5, currentIndex: _index, onTap: _onTap),
                const Spacer(),
                ListTile(
                  leading: const Icon(Icons.logout, color: Colors.black),
                  title: const Text("Logout", style: TextStyle(color: Colors.black)),
                  onTap: _logout,
                ),
              ],
            ),
          ),

          // Main content
          Expanded(
            child: Container(
              width: double.infinity,
              height: double.infinity,
              color: Colors.white,
              padding: const EdgeInsets.all(24),
              child: _pages[_index],
            ),
          ),
        ],
      ),
    );
  }
}

/// HomeWrapper: shows the "How to Book" guide alongside the provided HomePage widget.
/// - On wide screens: guide appears as a left card and HomePage on the right.
/// - On mobile: guide is a collapsible card above the HomePage content.
class HomeWrapper extends StatelessWidget {
  final String userId;
  final String fullName;
  final Widget child;

  const HomeWrapper({super.key, required this.userId, required this.fullName, required this.child});

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width >= 900;

    final guideCard = _HowToBookCard();

    if (isWide) {
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Left: Guide (fixed width)
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 360, minWidth: 320),
            child: Padding(
              padding: const EdgeInsets.only(right: 18.0),
              child: Column(
                children: [
                  guideCard,
                ],
              ),
            ),
          ),

          // Right: actual HomePage
          Expanded(child: child),
        ],
      );
    }

    // Mobile: collapsible guide on top
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 12.0),
          child: guideCard,
        ),
        Expanded(child: child),
      ],
    );
  }
}

/// Collapsible, friendly "How to Book" guide card
class _HowToBookCard extends StatefulWidget {
  @override
  State<_HowToBookCard> createState() => _HowToBookCardState();
}

class _HowToBookCardState extends State<_HowToBookCard> {
  bool _expanded = true;

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width >= 900;

    return Card(
      color: Colors.white,
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.all(16),
        width: double.infinity,
        child: Column(
          children: [
            Row(
              children: [
                const Icon(Icons.info_outline, color: Colors.green),
                const SizedBox(width: 12),
                const Expanded(child: Text("How to Book a Dialysis Session", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
                const SizedBox(width: 8),
                IconButton(
                  icon: Icon(_expanded ? Icons.expand_less : Icons.expand_more),
                  onPressed: () => setState(() => _expanded = !_expanded),
                ),
              ],
            ),
            if (_expanded) ...[
              const SizedBox(height: 8),
              const Text(
                "Follow these simple steps to secure a dialysis session. The guide is short — you can collapse it anytime.",
                style: TextStyle(color: Colors.black54),
              ),
              const SizedBox(height: 12),
              _stepRow(1, "Open Book → Choose a date & slot"),
              _stepRow(2, "Pick an available bed (system shows availability)"),
              _stepRow(3, "Confirm booking and wait for approval"),
              _stepRow(4, "You'll get notified when approved"),
              _stepRow(5, "Arrive on the scheduled date and check in"),
              const SizedBox(height: 12),
              ElevatedButton.icon(
                onPressed: () {
                  // quick action: navigate to Book tab if inside PatientDashboard
                  // find ancestor state and call onTap if possible
                  final state = context.findAncestorStateOfType<_PatientDashboardState>();
                  if (state != null) {
                    state._onTap(2);
                  }
                },
                icon: const Icon(Icons.add),
                label: const Text("Go to Book"),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
              )
            ]
          ],
        ),
      ),
    );
  }

  Widget _stepRow(int step, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 12,
            backgroundColor: Colors.green.shade100,
            child: Text('$step', style: const TextStyle(fontSize: 12, color: Colors.green)),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 14))),
        ],
      ),
    );
  }
}

class _PatientInfoCard extends StatelessWidget {
  final String username;
  final String email;
  final bool isLoading;
  final String? profileImageBase64;

  const _PatientInfoCard({
    required this.username,
    required this.email,
    required this.isLoading,
    this.profileImageBase64,
  });

  @override
  Widget build(BuildContext context) {
    final displayName = isLoading ? 'Loading...' : (username.isNotEmpty ? username : email);
    Widget profileWidget;

    if (isLoading) {
      profileWidget = const Center(
          child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)));
    } else if (profileImageBase64 != null && profileImageBase64!.isNotEmpty) {
      try {
        final imageBytes = base64Decode(profileImageBase64!);
        profileWidget = ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.memory(imageBytes, fit: BoxFit.cover, width: 48, height: 48));
      } catch (e) {
        profileWidget = const Icon(Icons.error, color: Colors.white, size: 28);
      }
    } else {
      profileWidget = const Icon(Icons.person, color: Colors.white, size: 28);
    }

    return Card(
      elevation: 0,
      color: Colors.green.shade50,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          children: [
            Container(width: 48, height: 48, decoration: BoxDecoration(color: Colors.green.shade300, borderRadius: BorderRadius.circular(8)), child: profileWidget),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(displayName, style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.green.shade800), overflow: TextOverflow.ellipsis),
                Text(email, style: const TextStyle(fontSize: 12, color: Colors.black54), overflow: TextOverflow.ellipsis),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}

class _WebNavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final int index;
  final int currentIndex;
  final void Function(int) onTap;
  final int badgeCount;

  const _WebNavItem({required this.icon, required this.label, required this.index, required this.currentIndex, required this.onTap, this.badgeCount = 0});

  @override
  Widget build(BuildContext context) {
    final isSelected = index == currentIndex;
    return ListTile(
      leading: Stack(
        clipBehavior: Clip.none,
        children: [
          Icon(icon, color: isSelected ? Colors.green : Colors.black54),
          if (badgeCount > 0 && index == 4)
            Positioned(
              right: -4,
              top: -4,
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                child: Text('$badgeCount', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
              ),
            ),
        ],
      ),
      title: Text(label, style: TextStyle(color: isSelected ? Colors.green : Colors.black54, fontWeight: isSelected ? FontWeight.bold : FontWeight.normal)),
      selected: isSelected,
      onTap: () => onTap(index),
    );
  }
}
