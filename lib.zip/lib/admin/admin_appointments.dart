// lib/admin/admin_appointments.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class AdminAppointmentsPage extends StatefulWidget {
  const AdminAppointmentsPage({super.key});

  @override
  State<AdminAppointmentsPage> createState() => _AdminAppointmentsPageState();
}

class _AdminAppointmentsPageState extends State<AdminAppointmentsPage> {
  final List<Map<String, dynamic>> defaultSlots = [
    {'label': '8:00 AM - 12:00 NN', 'startHour': 8, 'endHour': 12},
    {'label': '1:00 PM - 4:00 PM', 'startHour': 13, 'endHour': 16},
    {'label': '4:00 PM - 8:00 PM', 'startHour': 16, 'endHour': 20},
  ];

  void _showMessage(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: isError ? Colors.red : Colors.green,
      ),
    );
  }

  Future<void> _initializeSlotsIfNeeded() async {
    final firestore = FirebaseFirestore.instance.collection('session');
    final existing = await firestore.get();

    if (existing.docs.isEmpty) {
      for (var i = 0; i < defaultSlots.length; i++) {
        final s = defaultSlots[i];
        final now = DateTime.now();
        final startTime = DateTime(now.year, now.month, now.day, s['startHour']);
        final endTime = DateTime(now.year, now.month, now.day, s['endHour']);

        final doc = await firestore.add({
          'slotId': 'slot${i + 1}',
          'time': s['label'],
          'startTime': Timestamp.fromDate(startTime),
          'endTime': Timestamp.fromDate(endTime),
          'isActive': true,
          'status': 'available',
          'assignedPatients': [],
          'sessionDate': Timestamp.fromDate(DateTime(now.year, now.month, now.day)),
        });
        await doc.update({'slotId': doc.id});
      }
      _showMessage("Default slots initialized.");
    }
  }

  Future<void> _editSlotTime(String id, Map<String, dynamic> data) async {
    try {
      final startTs = data['startTime'] as Timestamp?;
      final endTs = data['endTime'] as Timestamp?;
      final base = DateTime.now();

      final currentStart = startTs?.toDate() ?? DateTime(base.year, base.month, base.day, 8);
      final currentEnd = endTs?.toDate() ?? DateTime(base.year, base.month, base.day, 12);

      final pickedStart = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.fromDateTime(currentStart),
      );
      if (pickedStart == null) return;

      final pickedEnd = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.fromDateTime(currentEnd),
      );
      if (pickedEnd == null) return;

      final newStart = DateTime(base.year, base.month, base.day, pickedStart.hour, pickedStart.minute);
      final newEnd = DateTime(base.year, base.month, base.day, pickedEnd.hour, pickedEnd.minute);

      if (!newEnd.isAfter(newStart)) {
        _showMessage("End time must be after start time.", isError: true);
        return;
      }

      final label = "${DateFormat.jm().format(newStart)} - ${DateFormat.jm().format(newEnd)}";

      await FirebaseFirestore.instance.collection('session').doc(id).update({
        'startTime': Timestamp.fromDate(newStart),
        'endTime': Timestamp.fromDate(newEnd),
        'time': label,
      });

      _showMessage("Slot time updated.");
    } catch (e) {
      _showMessage("Error updating slot: $e", isError: true);
    }
  }

  Future<void> _toggleActive(String id, bool newValue) async {
    try {
      await FirebaseFirestore.instance.collection('session').doc(id).update({
        'isActive': newValue,
        'status': newValue ? 'available' : 'unavailable',
      });
      _showMessage("Slot ${newValue ? 'enabled' : 'disabled'}");
    } catch (e) {
      _showMessage("Failed: $e", isError: true);
    }
  }

  Future<void> _deleteSlot(String id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Delete Slot"),
        content: const Text("Are you sure you want to delete this slot?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text("Cancel")),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text("Delete"),
          ),
        ],
      ),
    );

    if (confirm == true) {
      try {
        await FirebaseFirestore.instance.collection('session').doc(id).delete();
        _showMessage("Slot deleted");
      } catch (e) {
        _showMessage("Failed to delete: $e", isError: true);
      }
    }
  }

  @override
  void initState() {
    super.initState();
    _initializeSlotsIfNeeded();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Admin Slot Manager")),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collection('session')
              .orderBy('startTime', descending: false)
              .snapshots(), // ✅ No date filter here
          builder: (context, snap) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }

            final docs = snap.data?.docs ?? [];
            if (docs.isEmpty) {
              return const Center(child: Text("No slots found."));
            }

            return ListView.builder(
              itemCount: docs.length,
              itemBuilder: (context, index) {
                final doc = docs[index];
                final data = doc.data() as Map<String, dynamic>? ?? {};
                final isActive = data['isActive'] as bool? ?? true;
                final timeLabel = data['time'] ?? '---';
                final dateLabel = data['sessionDate'] != null
                    ? DateFormat('MMM d, yyyy').format((data['sessionDate'] as Timestamp).toDate())
                    : 'No Date';

                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 6),
                  child: ListTile(
                    title: Text(timeLabel, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text("Date: $dateLabel • Status: ${isActive ? 'Available' : 'Unavailable'}"),
                    leading: CircleAvatar(
                      backgroundColor: isActive ? Colors.green : Colors.red,
                      child: Text((index + 1).toString(),
                          style: const TextStyle(color: Colors.white)),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Switch(
                          value: isActive,
                          onChanged: (v) => _toggleActive(doc.id, v),
                          activeColor: Colors.green,
                        ),
                        IconButton(
                          icon: const Icon(Icons.edit, color: Colors.blue),
                          onPressed: () => _editSlotTime(doc.id, data),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _deleteSlot(doc.id),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
